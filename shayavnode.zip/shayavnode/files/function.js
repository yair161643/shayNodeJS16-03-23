const fs = require('node:fs/promises');
const path = require('node:path');
const util = require('util');

exports.Create = async (n, str) => {
    try {
        await fs.writeFile(path.join(__dirname, `file${n}.txt`), str);
    } catch (error) {
        console.error(error);
    }
};

exports.Read = async (n) => {
    try {
        const data = await fs.readFile(path.join(__dirname, `file${n}.txt`), 'utf8');
        return data;
    } catch (error) {
        console.error(error);
    }
};

exports.GetRandNumber = async () => {
    const rand = Math.floor(Math.random() * 6);
    return rand;
};

exports.ConcaFiles = async () => {
    const fullTextFilePath = path.join(__dirname, 'concatTextFile.txt');
    await fs.unlink(fullTextFilePath);
    const randomNum = await exports.GetRandNumber();
    console.log(randomNum);

    let theFullText = '';

    const files = await fs.readdir(__dirname);
    for (const file of files) {
        if (file.includes(randomNum)) {
            const filePath = path.join(__dirname, file);
            const data = await fs.readFile(filePath, 'utf8');
            theFullText += data + '\n';
            console.log(`Reached ${file}. Stopping.`);
            break;
        }

        if (path.extname(file) === '.txt') {
            const filePath = path.join(__dirname, file);
            const data = await fs.readFile(filePath, 'utf8');
            theFullText += data + '\n';
        }
    }

    await fs.writeFile(fullTextFilePath, theFullText);
};
