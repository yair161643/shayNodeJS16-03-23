


exports.MaxNumber=(a,b,c)=>{let m = Math.max(a,b) 
    return Math.max(m,c)}

   




exports.PrintNTimes=(a,n) =>{

    for (let index = 0; index < n; index++) {
        console.log(a)
        
    }
 }


 exports.howMuchAfterDot=(a) =>{
    a=a.toString()
    console.log(a)
    let arr = a.split(".")
    console.log(arr)
    return arr[1].length 
 }