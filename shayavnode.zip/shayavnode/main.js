const {Create,Read, GetRandNumber, ConcaFiles} = require("./files/function")

// const {PrintNTimes,MaxNumber} = require("./function")


async function main() {
    


    
    ConcaFiles()
    

}

main();